package com.example.freelook;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class FreelookConfigScreen extends Screen {
    private final Screen parent;
    private boolean listening = false;
    private ButtonWidget keyButton;
    private ButtonWidget modeButton;
    private ButtonWidget perspectiveButton;

    public FreelookConfigScreen(Screen parent) {
        super(Text.literal("Freelook Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = 220, x = width / 2 - w / 2, y = height / 4;

        keyButton = addDrawableChild(ButtonWidget.builder(keyText(), b -> {
            listening = true;
            b.setMessage(Text.literal("> Press a key <"));
        }).dimensions(x, y, w, 20).build());

        addDrawableChild(new DistanceSlider(x, y + 24, w, 20));

        modeButton = addDrawableChild(ButtonWidget.builder(modeText(), b -> {
            FreelookConfig.holdMode = !FreelookConfig.holdMode;
            b.setMessage(modeText());
        }).dimensions(x, y + 48, w, 20).build());

        perspectiveButton = addDrawableChild(ButtonWidget.builder(perspectiveText(), b -> {
            FreelookConfig.thirdPerson = !FreelookConfig.thirdPerson;
            b.setMessage(perspectiveText());
        }).dimensions(x, y + 72, w, 20).build());

        addDrawableChild(ButtonWidget.builder(ScreenTexts.DONE, b -> close())
                .dimensions(x, y + 104, w, 20).build());
    }

    private Text keyText() {
        return Text.literal("Key: ").append(FreelookClient.KEY.getBoundKeyLocalizedText());
    }

    private Text modeText() {
        return Text.literal("Mode: " + (FreelookConfig.holdMode ? "Hold" : "Toggle"));
    }

    private Text perspectiveText() {
        return Text.literal("Third Person While Active: " + (FreelookConfig.thirdPerson ? "ON" : "OFF"));
    }

    private void bind(InputUtil.Key key) {
        FreelookClient.KEY.setBoundKey(key);
        KeyBinding.updateKeysByCode();
        client.options.write();
        listening = false;
        keyButton.setMessage(keyText());
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                listening = false;
                keyButton.setMessage(keyText());
            } else {
                bind(InputUtil.fromKeyCode(keyCode, scanCode));
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (listening) {
            bind(InputUtil.Type.MOUSE.createFromCode(button));
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 4 - 24, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        FreelookConfig.save();
        client.setScreen(parent);
    }

    private static class DistanceSlider extends SliderWidget {
        DistanceSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(),
                    (FreelookConfig.distance - FreelookConfig.MIN_DISTANCE)
                            / (FreelookConfig.MAX_DISTANCE - FreelookConfig.MIN_DISTANCE));
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(String.format("Camera Distance: %.1f", FreelookConfig.distance)));
        }

        @Override
        protected void applyValue() {
            double d = FreelookConfig.MIN_DISTANCE
                    + value * (FreelookConfig.MAX_DISTANCE - FreelookConfig.MIN_DISTANCE);
            FreelookConfig.distance = Math.round(d * 2.0) / 2.0; // steps of 0.5
        }
    }
}
