package com.example.freelook.mixin;

import com.example.freelook.FreelookClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    // Mouse movement goes to the camera instead of the player while freelooking
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void freelook$mouse(double dx, double dy, CallbackInfo ci) {
        if (FreelookClient.active && (Object) this == MinecraftClient.getInstance().player) {
            FreelookClient.yaw += (float) dx * 0.15F;
            FreelookClient.pitch += (float) dy * 0.15F;
            FreelookClient.pitch = Math.max(-90F, Math.min(90F, FreelookClient.pitch));
            ci.cancel();
        }
    }
}
