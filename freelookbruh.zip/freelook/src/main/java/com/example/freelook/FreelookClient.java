package com.example.freelook;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class FreelookClient implements ClientModInitializer {
    public static KeyBinding KEY;
    public static boolean active = false;
    public static float yaw, pitch;
    private static Perspective previous = Perspective.FIRST_PERSON;

    @Override
    public void onInitializeClient() {
        FreelookConfig.load();

        KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.freelook.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, "key.categories.misc"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) { active = false; return; }
            if (FreelookConfig.holdMode) {
                // don't trigger while typing in a screen (e.g. the config screen's own key picker)
                boolean down = client.currentScreen == null && KEY.isPressed();
                if (down && !active) start(client);
                else if (!down && active) stop(client);
            } else {
                while (KEY.wasPressed()) {
                    if (active) stop(client); else start(client);
                }
            }
        });
    }

    private static void start(MinecraftClient c) {
        active = true;
        yaw = c.player.getYaw();
        pitch = c.player.getPitch();
        previous = c.options.getPerspective();
        if (FreelookConfig.thirdPerson && previous == Perspective.FIRST_PERSON) {
            c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        }
    }

    private static void stop(MinecraftClient c) {
        active = false;
        if (FreelookConfig.thirdPerson) c.options.setPerspective(previous);
    }
}
