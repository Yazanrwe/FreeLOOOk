package com.example.freelook;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class FreelookConfig {
    public static boolean holdMode = true;      // true = hold key, false = press to toggle
    public static boolean thirdPerson = true;   // switch to third person while freelooking
    public static double distance = 4.0;        // camera distance while freelooking

    public static final double MIN_DISTANCE = 1.0;
    public static final double MAX_DISTANCE = 20.0;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("freelook.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (!Files.exists(p)) { save(); return; }
            JsonObject o = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
            if (o.has("holdMode")) holdMode = o.get("holdMode").getAsBoolean();
            if (o.has("thirdPerson")) thirdPerson = o.get("thirdPerson").getAsBoolean();
            if (o.has("distance")) {
                distance = Math.max(MIN_DISTANCE, Math.min(MAX_DISTANCE, o.get("distance").getAsDouble()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("holdMode", holdMode);
            o.addProperty("thirdPerson", thirdPerson);
            o.addProperty("distance", distance);
            Files.writeString(path(), GSON.toJson(o));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
