package com.example.freelook.mixin;

import com.example.freelook.FreelookClient;
import com.example.freelook.FreelookConfig;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(Camera.class)
public class CameraMixin {
    // Replace the rotation the camera is set to with our free rotation
    @ModifyArgs(method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"))
    private void freelook$rotation(Args args) {
        if (FreelookClient.active) {
            args.set(0, FreelookClient.yaw);
            args.set(1, FreelookClient.pitch);
        }
    }

    // Camera distance in third person while freelooking
    @ModifyArg(method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;clipToSpace(D)D"),
            index = 0)
    private double freelook$distance(double original) {
        return FreelookClient.active ? FreelookConfig.distance : original;
    }
}
